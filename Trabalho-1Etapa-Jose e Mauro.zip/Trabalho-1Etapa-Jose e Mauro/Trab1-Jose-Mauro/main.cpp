
// Trabalho 1° Etapa de Computação Gráfica
// Alunos: Mauro A. Ré Jr e José Henrique

#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>
#include <Eigen/Dense>
#include "TRANS2D.hpp"

using namespace std;
using namespace Eigen;

int returnSeg();

string returnTransf();

void preparaMat(Matrix3f &M, string transf, int seg, PGM *imgE, PGM *imgAux);
void transforma(Matrix3f &M, int seg, PGM *imgE, PGM *imgAux);

PGM *imgS = NULL;
int main(void)
{

        setlocale(LC_ALL, "Portuguese");

        int seg;
        int op_menu;
        string transf;
        string img;

        PGM *imgE = new PGM();
        imgS = new PGM();
        PGM *imgAux = new PGM();

        Eigen::Matrix3f M1 = Eigen::Matrix3f::Identity();
        Eigen::Matrix3f M2 = Eigen::Matrix3f::Identity();
        Eigen::Matrix3f M3 = Eigen::Matrix3f::Identity();
        Eigen::Matrix3f M4 = Eigen::Matrix3f::Identity();

        cout << "Informe a imagem: ";
        cin >> img;

        imgE->ler(img);

        imgS->criar(imgE->getLargura() * 2, imgE->getAltura() * 2);
        imgS->gravar("saida.pgm");

        do
        {
                cout << "\n Digite 1 para aplicar uma transformacao, ou 0 para sair: ";
                cin >> op_menu;

                if (op_menu == 0)
                {

                        cout << "PROGRAMA FINALIZADO!";
                        break;
                }
                else
                {
                        seg = returnSeg();
                        transf = returnTransf();

                        if (seg == 1)
                        {

                                preparaMat(M1, transf, seg, imgE, imgAux);
                        }
                        else if (seg == 2)
                        {

                                preparaMat(M2, transf, seg, imgE, imgAux);
                        }
                        else if (seg == 3)
                        {

                                preparaMat(M3, transf, seg, imgE, imgAux);
                        }
                        else if (seg == 4)
                        {

                                preparaMat(M4, transf, seg, imgE, imgAux);
                        }
                }
        } while (op_menu != 0);

        delete imgE;
        delete imgS;

        return EXIT_SUCCESS;
}

int returnSeg()
{
        int seg;

        do
        {
                cout << "\n Escolha o segmento: (1, 2, 3 ou 4): ";
                cin >> seg;

        } while (seg < 1 || seg > 4);

        return seg;
}

string returnTransf()
{

        string transf;

        do
        {
                cout << "\n Transformacoes Geometricas Disponiveis: \n"
                     << endl
                     << "T - Translacao " << endl
                     << "R - Rotacao" << endl
                     << "E - Escala" << endl
                     << "C - Cisalhamento  " << endl
                     << "RE - Reflexao " << endl
                     << "\n Opcao:  ";
                cin >> transf;

                for (int i = 0; i < transf.length(); i++)
                {

                        transf[i] = toupper(transf[i]);
                }
        } while (transf != "T" && transf != "R" && transf != "E" && transf != "C" && transf != "RE");

        return transf;
}

void preparaMat(Matrix3f &M, string transf, int seg, PGM *imgE, PGM *imgAux)
{

        Eigen::Matrix3f Matfinal = Eigen::Matrix3f::Identity();
        Eigen::Vector2f centro(imgE->getLargura() / 2.0f, imgE->getAltura() / 2.0f);
        Eigen::Matrix3f Tr = Trans2D::getMTranslacao(centro(0), centro(1));
        Eigen::Matrix3f Tinv = Trans2D::getMTranslacao(-centro(0), -centro(1));

        if (transf == "T")
        {
                float tx, ty;
                cout << "\nTranslacao => " << endl;
                cout << "Informe Tx: ";
                cin >> tx;
                fflush(stdin);
                cout << "Informe Ty: ";
                cin >> ty;
                fflush(stdin);
                Eigen::Matrix3f T = Trans2D::getMTranslacao(tx, ty);
                M = T * M;
                cout << "\n Translacao aplicada." << endl;
        }

        else if (transf == "R")
        {
                float angulo;
                cout << "\nRotacao => " << endl;
                cout << "Informe o angulo: ";
                cin >> angulo;
                fflush(stdin);
                Eigen::Matrix3f R = Trans2D::getMRotacao(angulo);
                M = R * M;
                cout << "\n Rotacao aplicada." << endl;
        }

        else if (transf == "E")
        {
                float sx, sy;
                cout << "\nEscala => " << endl;
                cout << "Informe Sx: ";
                cin >> sx;
                fflush(stdin);
                cout << "Informe Sy: ";
                cin >> sy;
                fflush(stdin);
                Eigen::Matrix3f S = Trans2D::getMEscala(sx, sy);
                M = S * M;
                cout << "\n Escala aplicada." << endl;
        }
        else if (transf == "RE")
        {
                char eixo;
                float sx, sy;

                do
                {
                        cout << "\nReflexao => " << endl;
                        cout << "Informe o eixo: ";
                        cin >> eixo;
                        fflush(stdin);
                        eixo = toupper(eixo);
                } while (eixo != 'X' && eixo != 'Y');

                Eigen::Matrix3f RE = Trans2D::getMReflexao(eixo);
                M = RE * M;
                cout << "\n Reflexao aplicada." << endl;
        }
        else if (transf == "C")
        {
                char sentido;
                float fator;
                do
                {
                        cout << "\nCisalhamento => " << endl;
                        cout << "Informe o sentido (H ou V): ";
                        cin >> sentido;
                        fflush(stdin);
                        sentido = toupper(sentido);
                } while (sentido != 'H' && sentido != 'V');

                cout << "Informe o fator: ";
                cin >> fator;
                fflush(stdin);

                Eigen::Matrix3f CI = Trans2D::getMCisalhamento(sentido, fator);
                M = CI * M;
                cout << "\n Cisalhamento aplicado." << endl;
        }

        Matfinal = Tr * M * Tinv;

        transforma(Matfinal, seg, imgE, imgAux);
}

void transforma(Matrix3f &M, int seg, PGM *imgE, PGM *imgAux)
{

        int sx = 0, sy = 0;
        switch (seg)
        {
        case 1:
                sx = 0;
                sy = 0;
                break;

        case 2:
                sx = 0;
                sy = imgAux->getAltura();
                break;

        case 3:
                sx = imgAux->getLargura();
                sy = 0;
                break;

        case 4:
                sx = imgAux->getLargura();
                sy = imgAux->getAltura();
                break;

        default:
                break;
        }

        imgAux->criar(imgE->getLargura(), imgE->getAltura());
        Trans2D::transform2DInv(M, imgE, imgAux);

        for (int i = 0; i < imgAux->getLargura(); i++)
        {
                for (int i1 = 0; i1 < imgAux->getAltura(); i1++)
                {
                        unsigned char cor = imgAux->getPixel(i, i1);
                        imgS->setPixel((sx + i), (sy + i1), cor);
                }
        }

        imgS->gravar("saida.pgm");
}
